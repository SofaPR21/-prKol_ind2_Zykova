﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prKol_ind2_Zykova_v8
{
    internal class Person
    {
        private string _surname;
        private string _name;
        private string _thirdname;
        private string _pol;
        private int _age;
        private double _zarplata;

        public Person() { }

        public Person(string fam, string name, string ot, string pol, int age, double zp)
        {
            this._surname = fam;
            this._name = name;
            this._thirdname = ot;
            this._pol = pol;
            this._age = age;
            this._zarplata = zp;
        }

        public string SurnameValue
        {
            get { return _surname; }
            set { _surname = value; }
        }

        public string NameValue
        {
            get { return _name; }
            set { _name = value; }
        }

        public string ThirdnameValue
        {
            get { return _thirdname; }
            set { _thirdname = value; }
        }

        public string PolValue
        {
            get { return _pol; }
            set { _pol = value; }
        }

        public int AgeValue
        {
            get { return _age; }
            set { _age = value; }
        }

        public double ZarplataValue
        {
            get { return _zarplata; }
            set { _zarplata = value; }
        }
    }
}
