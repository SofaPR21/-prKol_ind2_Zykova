using System.Windows.Forms;
using System;

namespace prKol_ind2_Zykova_v8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            Queue<Person> people = new Queue<Person>();
            string file = "file.txt";

            if (File.Exists(file))
            {
                try
                {
                    string[] s = File.ReadAllLines(file);

                    Person p1;

                    foreach (string text in s)
                    {
                        string[] person = text.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                        string surname = person[0];
                        string name = person[1];
                        string thirdname = person[2];
                        string pol = person[3];
                        int age = int.Parse(person[4]);
                        double zp = double.Parse(person[5]);

                        p1 = new Person(surname, name, thirdname, pol, age, zp);

                        listBox2.Items.Add($"{p1.ThirdnameValue} {p1.NameValue} {p1.SurnameValue}, �������: {p1.AgeValue} ���, ��������:{p1.ZarplataValue} ���");
                        people.Enqueue(new Person(surname, name, thirdname, pol, age, zp));
                    }

                    var younPerson = people.Where(p => p.AgeValue < 30);

                    foreach (var y in younPerson)
                    {
                        listBox1.Items.Add($"{y.ThirdnameValue} {y.NameValue} {y.SurnameValue}, �������: {y.AgeValue} ���, ��������:{y.ZarplataValue} ���");
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show($"������ ��� ������ ����� {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("���� �� ������", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        } 
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
