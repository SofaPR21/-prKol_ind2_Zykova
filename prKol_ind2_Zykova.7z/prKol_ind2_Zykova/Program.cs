﻿using System;
using System.IO;
using System.Collections.Generic;


namespace prKol_ind2_Zykova
{
    class Program
    {
        static void Main(string[] args)
        { 
            string file = "text.txt";
            Queue<string> studens = new Queue<string>();
            try 
            {
                using (StreamReader str = new StreamReader(file))
                {
                    string line;

                    while ((line = str.ReadLine()) != null)
                    {
                        string[] probel = line.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                        if (probel.Length >= 5)
                        {
                            string fullName = string.Join(" ", probel[0..3]);

                            string group = probel[3];

                            List<int> grades = new List<int>();
                            for(int i = 4; i < probel.Length; i++)
                            {
                                /*if (int.Parse(probel[i].Trim(), out int score))
                                {

                                }*/
                            }
                        }
                    }
                    
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Ошибка при чтении файла");
                return;
            }
        }
    }
}
